HELLO! thank you for supporting my project if you know pcb work please feel free to join the discord!!

PLA, Standard settings with supports.

ABS, Possible but enclosure is nessesary, and a lot of patience/pain.

PETG, I wouldnt do this until you get your print settings right with pla first.

Thx for all the support!!!