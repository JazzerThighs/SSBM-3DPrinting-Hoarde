# wumble
 "as in the wav-rumble"
 
- rumble bracket made to support mouse switch trigger boards and cellphone rumble.
 
- based on FiresCC's rumble bracket @ https://github.com/FIRESCustom/GCC_Rumble_Bracket
 
- message me on discord if you have any issues or questions @ wav#9999
